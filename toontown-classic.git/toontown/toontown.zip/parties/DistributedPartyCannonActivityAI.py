from direct.directnotify import DirectNotifyGlobal
from toontown.parties.DistributedPartyActivityAI import DistributedPartyActivityAI

class DistributedPartyCannonActivityAI(DistributedPartyActivityAI):
    notify = DirectNotifyGlobal.directNotify.newCategory("DistributedPartyCannonActivityAI")

    def setMovie(self, todo0, todo1):
        pass

    def setLanded(self, todo0):
        pass

    def setCannonWillFire(self, todo0, todo1, todo2):
        pass

    def cloudsColorRequest(self):
        pass

    def cloudsColorResponse(self, todo0):
        pass

    def requestCloudHit(self, todo0, todo1, todo2, todo3):
        pass

    def setCloudHit(self, todo0, todo1, todo2, todo3):
        pass

    def setToonTrajectoryAi(self, todo0, todo1, todo2, todo3, todo4, todo5, todo6, todo7, todo8, todo9):
        pass

    def setToonTrajectory(self, todo0, todo1, todo2, todo3, todo4, todo5, todo6, todo7, todo8, todo9, todo10):
        pass

    def updateToonTrajectoryStartVelAi(self, todo0, todo1, todo2):
        pass

    def updateToonTrajectoryStartVel(self, todo0, todo1, todo2, todo3):
        pass

